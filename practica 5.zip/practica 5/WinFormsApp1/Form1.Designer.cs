namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitulo  = new Label();
            lblRadio   = new Label();
            lblAltura  = new Label();
            lblBase    = new Label();
            lblLateral = new Label();
            lblTotal   = new Label();
            lblVol     = new Label();
            textBox1   = new TextBox();
            textBox2   = new TextBox();
            textBox3   = new TextBox();
            textBox4   = new TextBox();
            textBox5   = new TextBox();
            textBox6   = new TextBox();
            button1    = new Button();
            button2    = new Button();
            button3    = new Button();
            SuspendLayout();
            var bf    = new Font("Arial", 11F, FontStyle.Bold | FontStyle.Italic);
            var bfOut = new Font("Arial", 11F, FontStyle.Bold);
            // lblTitulo
            lblTitulo.AutoSize  = true;
            lblTitulo.Font      = new Font("Arial", 13F, FontStyle.Bold);
            lblTitulo.ForeColor = System.Drawing.Color.DarkGreen;
            lblTitulo.Location  = new Point(30, 18);
            lblTitulo.Text      = "Introduce las Dimensiones del Cilindro";
            // lblRadio
            lblRadio.AutoSize = true; lblRadio.Font = bf;
            lblRadio.Location = new Point(40, 80); lblRadio.Text = "Radio";
            // textBox1
            textBox1.Font = new Font("Arial", 11F, FontStyle.Italic);
            textBox1.Location = new Point(170, 76); textBox1.Name = "textBox1";
            textBox1.Size = new Size(130, 31); textBox1.TabIndex = 0;
            // lblAltura
            lblAltura.AutoSize = true; lblAltura.Font = bf;
            lblAltura.Location = new Point(40, 130); lblAltura.Text = "Altura";
            // textBox2
            textBox2.Font = new Font("Arial", 11F, FontStyle.Italic);
            textBox2.Location = new Point(170, 126); textBox2.Name = "textBox2";
            textBox2.Size = new Size(130, 31); textBox2.TabIndex = 1;
            // Botones
            var btnFont = new Font("Arial", 10F, FontStyle.Bold | FontStyle.Italic);
            button1.Font = btnFont; button1.Location = new Point(40, 180);
            button1.Size = new Size(100, 32); button1.Text = "Calcular";
            button1.Click += button1_Click;
            button2.Font = btnFont; button2.Location = new Point(155, 180);
            button2.Size = new Size(100, 32); button2.Text = "Borrar";
            button2.Click += button2_Click;
            button3.Font = btnFont; button3.Location = new Point(270, 180);
            button3.Size = new Size(100, 32); button3.Text = "Salir";
            button3.Click += button3_Click;
            // Resultados
            string[] rLabs = { "Base área", "Lateral área", "Total área", "Volumen" };
            var rLabObjs = new[] { lblBase, lblLateral, lblTotal, lblVol };
            var rTbs     = new[] { textBox3, textBox4, textBox5, textBox6 };
            for (int i = 0; i < 4; i++)
            {
                int y = 240 + i * 48;
                rLabObjs[i].AutoSize  = true;
                rLabObjs[i].Font      = bfOut;
                rLabObjs[i].ForeColor = System.Drawing.Color.DarkMagenta;
                rLabObjs[i].Location  = new Point(40, y + 4);
                rLabObjs[i].Text      = rLabs[i];
                rTbs[i].Font          = new Font("Arial", 10F);
                rTbs[i].Location      = new Point(180, y);
                rTbs[i].Size          = new Size(160, 31);
                rTbs[i].ReadOnly      = true;
                rTbs[i].BackColor     = System.Drawing.Color.White;
                rTbs[i].TabIndex      = 10 + i;
            }
            // Form1
            BackColor = System.Drawing.Color.Yellow;
            ClientSize = new Size(460, 450);
            Controls.Add(lblTitulo);
            Controls.Add(lblRadio);   Controls.Add(textBox1);
            Controls.Add(lblAltura);  Controls.Add(textBox2);
            Controls.Add(button1); Controls.Add(button2); Controls.Add(button3);
            foreach (var l in rLabObjs) Controls.Add(l);
            foreach (var t in rTbs)     Controls.Add(t);
            Name = "Form1"; Text = "Cilindro";
            ResumeLayout(false); PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo, lblRadio, lblAltura;
        private System.Windows.Forms.Label lblBase, lblLateral, lblTotal, lblVol;
        private System.Windows.Forms.TextBox textBox1, textBox2, textBox3;
        private System.Windows.Forms.TextBox textBox4, textBox5, textBox6;
        private System.Windows.Forms.Button button1, button2, button3;
    }
}
