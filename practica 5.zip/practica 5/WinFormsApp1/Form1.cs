using System;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)   // Calcular
        {
            double Radius = double.Parse(textBox1.Text);
            double Height = double.Parse(textBox2.Text);

            double BaseArea    = Radius * Radius * Math.PI;
            double LateralArea = 2 * Math.PI * Radius * Height;
            double TotalArea   = 2 * Math.PI * Radius * (Height + Radius);
            double Volume      = Math.PI * Radius * Radius * Height;

            textBox3.Text = BaseArea.ToString("0.##");
            textBox4.Text = LateralArea.ToString("0.##");
            textBox5.Text = TotalArea.ToString("0.##");
            textBox6.Text = Volume.ToString("0.##");
        }

        private void button2_Click(object sender, EventArgs e)   // Borrar
        {
            textBox1.Clear(); textBox2.Clear();
            textBox3.Clear(); textBox4.Clear();
            textBox5.Clear(); textBox6.Clear();
        }

        private void button3_Click(object sender, EventArgs e)   // Salir
        {
            this.Close();
        }
    }
}
