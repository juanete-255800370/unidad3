namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private static Label MkLbl(string txt, int x, int y, float sz = 11F,
            FontStyle fs = FontStyle.Bold,
            System.Drawing.Color? col = null)
        {
            var l = new Label { AutoSize = true, Font = new Font("Arial", sz, fs),
                                Location = new Point(x, y), Text = txt };
            if (col.HasValue) l.ForeColor = col.Value;
            return l;
        }
        private static TextBox MkTb(string name, int x, int y, int w = 130, bool ro = false)
            => new TextBox { Name = name, Location = new Point(x, y),
                             Size = new Size(w, 31), ReadOnly = ro,
                             BackColor = System.Drawing.Color.White };
        private static Button MkBtn(string txt, int x, int y,
            System.Drawing.Color? bc = null)
        {
            var b = new Button { Text = txt, Font = new Font("Arial", 9F, FontStyle.Bold),
                                 Location = new Point(x, y), Size = new Size(88, 30) };
            if (bc.HasValue) { b.BackColor = bc.Value; b.UseVisualStyleBackColor = false; }
            return b;
        }

        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabCirc = new TabPage(); tabTri  = new TabPage(); tabCubo  = new TabPage();
            tabCil  = new TabPage(); tabRombo= new TabPage(); tabOct   = new TabPage();

            radioCirc    = MkTb("radioCirc",   155, 75);
            areaCirc     = MkTb("areaCirc",    155, 155, 130, true);
            VolumenCirc  = MkTb("VolumenCirc", 380, 155, 130, true);

            baseTri      = MkTb("baseTri",   180, 70);
            alturaTri    = MkTb("alturaTri", 370, 70);
            areaTri      = MkTb("areaTri",   155, 215, 130, true);

            ladoCubo     = MkTb("ladoCubo",    190, 75);
            areaCubo     = MkTb("areaCubo",    190, 130, 130, true);
            volumenCubo  = MkTb("volumenCubo", 190, 185, 130, true);

            radioCil     = MkTb("radioCil",  190, 75);
            alturaCil    = MkTb("alturaCil", 190, 125);
            areaCil      = MkTb("areaCil",   190, 185, 130, true);
            volumenCil   = MkTb("volumenCil",190, 240, 130, true);

            diagD        = MkTb("diagD",    195, 75);
            diagd        = MkTb("diagd",    195, 125);
            areaRombo    = MkTb("areaRombo",195, 195, 130, true);

            aristaOct    = MkTb("aristaOct",  195, 75);
            areaOct      = MkTb("areaOct",    195, 145, 130, true);
            volumenOct   = MkTb("volumenOct", 195, 200, 130, true);

            var orange = System.Drawing.Color.Orange;

            // Botones Circunferencia
            var bCC = MkBtn("Calcular", 50,  265); bCC.Click += btnCalcCirc_Click;
            var bBC = MkBtn("Borrar",  150,  265); bBC.Click += btnBorrCirc_Click;
            var bSC = MkBtn("Salir",   250,  265); bSC.Click += btnSalirCirc_Click;
            // Botones Triángulo
            var bCT = MkBtn("Calcular", 50,  275, orange); bCT.Click += btnCalcTri_Click;
            var bBT = MkBtn("Borrar",  150,  275, orange); bBT.Click += btnBorrTri_Click;
            var bST = MkBtn("Salir",   250,  275, orange); bST.Click += btnSalirTri_Click;
            // Botones Cubo
            var bCCu = MkBtn("Calcular", 50, 255); bCCu.Click += btnCalcCubo_Click;
            var bBCu = MkBtn("Borrar",  150, 255); bBCu.Click += btnBorrCubo_Click;
            var bSCu = MkBtn("Salir",   250, 255); bSCu.Click += btnSalirCubo_Click;
            // Botones Cilindro
            var bCCi = MkBtn("Calcular", 50, 295); bCCi.Click += btnCalcCil_Click;
            var bBCi = MkBtn("Borrar",  150, 295); bBCi.Click += btnBorrCil_Click;
            var bSCi = MkBtn("Salir",   250, 295); bSCi.Click += btnSalirCil_Click;
            // Botones Rombo
            var bCR = MkBtn("Calcular", 50, 265); bCR.Click += btnCalcRombo_Click;
            var bBR = MkBtn("Borrar",  150, 265); bBR.Click += btnBorrRombo_Click;
            var bSR = MkBtn("Salir",   250, 265); bSR.Click += btnSalirRombo_Click;
            // Botones Octaedro
            var bCO = MkBtn("Calcular", 50, 265); bCO.Click += btnCalcOct_Click;
            var bBO = MkBtn("Borrar",  150, 265); bBO.Click += btnBorrOct_Click;
            var bSO = MkBtn("Salir",   250, 265); bSO.Click += btnSalirOct_Click;

            // TabControl
            tabControl1.Location = new Point(0, 0);
            tabControl1.Size = new Size(700, 370);
            tabControl1.TabIndex = 0;
            tabControl1.Controls.AddRange(new[] { tabCirc, tabTri, tabCubo, tabCil, tabRombo, tabOct });

            // Tab Circunferencia
            tabCirc.BackColor = System.Drawing.Color.Wheat; tabCirc.Text = "Circunferencia";
            tabCirc.Controls.AddRange(new Control[] {
                MkLbl("Circunferencia", 210, 22, 16F),
                MkLbl("Radio",  40, 78), radioCirc,
                MkLbl("Area",   40, 158), areaCirc,
                MkLbl("Volumen",280, 158), VolumenCirc,
                bCC, bBC, bSC });

            // Tab Triángulo
            tabTri.BackColor = System.Drawing.Color.MistyRose; tabTri.Text = "Triángulo";
            tabTri.Controls.AddRange(new Control[] {
                MkLbl("Triángulo", 240, 18, 16F),
                MkLbl("Base",  40, 73),  baseTri,
                MkLbl("Altura",290, 73), alturaTri,
                MkLbl("Area",  40, 218), areaTri,
                bCT, bBT, bST });

            // Tab Cubo
            tabCubo.Text = "Cubo";
            tabCubo.Controls.AddRange(new Control[] {
                MkLbl("Cubo", 280, 18, 16F),
                MkLbl("Lado",    40, 78),  ladoCubo,
                MkLbl("Area",    40, 133), areaCubo,
                MkLbl("Volumen", 40, 188), volumenCubo,
                bCCu, bBCu, bSCu });

            // Tab Cilindro
            tabCil.Text = "Cilindro";
            tabCil.Controls.AddRange(new Control[] {
                MkLbl("Cilindro", 265, 18, 16F),
                MkLbl("Radio",   40, 78),  radioCil,
                MkLbl("Altura",  40, 128), alturaCil,
                MkLbl("Area",    40, 188), areaCil,
                MkLbl("Volumen", 40, 243), volumenCil,
                bCCi, bBCi, bSCi });

            // Tab Rombo
            tabRombo.Text = "Rombo";
            tabRombo.Controls.AddRange(new Control[] {
                MkLbl("Rombo", 275, 18, 16F),
                MkLbl("Diagonal D", 40, 78),  diagD,
                MkLbl("Diagonal d", 40, 128), diagd,
                MkLbl("Area",       40, 198), areaRombo,
                bCR, bBR, bSR });

            // Tab Octaedro
            tabOct.Text = "Octaedro";
            tabOct.Controls.AddRange(new Control[] {
                MkLbl("Octaedro", 260, 18, 16F),
                MkLbl("Arista",  40, 78),  aristaOct,
                MkLbl("Area",    40, 148), areaOct,
                MkLbl("Volumen", 40, 203), volumenOct,
                bCO, bBO, bSO });

            // Form1
            ClientSize = new Size(700, 370);
            Controls.Add(tabControl1);
            Name = "Form1"; Text = "Figuras Geométricas";
            ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabCirc, tabTri, tabCubo, tabCil, tabRombo, tabOct;
        private System.Windows.Forms.TextBox radioCirc, areaCirc, VolumenCirc;
        private System.Windows.Forms.TextBox baseTri, alturaTri, areaTri;
        private System.Windows.Forms.TextBox ladoCubo, areaCubo, volumenCubo;
        private System.Windows.Forms.TextBox radioCil, alturaCil, areaCil, volumenCil;
        private System.Windows.Forms.TextBox diagD, diagd, areaRombo;
        private System.Windows.Forms.TextBox aristaOct, areaOct, volumenOct;
    }
}
