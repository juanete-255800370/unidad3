using System;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // ── Circunferencia (Esfera) ──────────────────────────────────────────
        private void btnCalcCirc_Click(object sender, EventArgs e)
        {
            const double pi = 3.141592;
            double radio1   = double.Parse(radioCirc.Text);
            double area1    = 4 * pi * radio1 * radio1;
            double volumen1 = 4.0 / 3.0 * pi * Math.Pow(radio1, 3);
            areaCirc.Text    = area1.ToString("0.##");
            VolumenCirc.Text = volumen1.ToString("0.##");
        }
        private void btnBorrCirc_Click(object sender, EventArgs e)
        { radioCirc.Clear(); areaCirc.Clear(); VolumenCirc.Clear(); }
        private void btnSalirCirc_Click(object sender, EventArgs e) { Close(); }

        // ── Triángulo ────────────────────────────────────────────────────────
        private void btnCalcTri_Click(object sender, EventArgs e)
        {
            double b = double.Parse(baseTri.Text);
            double h = double.Parse(alturaTri.Text);
            areaTri.Text = (b * h / 2).ToString("0.##");
        }
        private void btnBorrTri_Click(object sender, EventArgs e)
        { baseTri.Clear(); alturaTri.Clear(); areaTri.Clear(); }
        private void btnSalirTri_Click(object sender, EventArgs e) { Close(); }

        // ── Cubo ─────────────────────────────────────────────────────────────
        private void btnCalcCubo_Click(object sender, EventArgs e)
        {
            double a = double.Parse(ladoCubo.Text);
            areaCubo.Text    = (6 * a * a).ToString("0.##");
            volumenCubo.Text = Math.Pow(a, 3).ToString("0.##");
        }
        private void btnBorrCubo_Click(object sender, EventArgs e)
        { ladoCubo.Clear(); areaCubo.Clear(); volumenCubo.Clear(); }
        private void btnSalirCubo_Click(object sender, EventArgs e) { Close(); }

        // ── Cilindro ─────────────────────────────────────────────────────────
        private void btnCalcCil_Click(object sender, EventArgs e)
        {
            const double pi = 3.141592;
            double r = double.Parse(radioCil.Text);
            double h = double.Parse(alturaCil.Text);
            areaCil.Text    = (2 * pi * r * h + 2 * pi * r * r).ToString("0.##");
            volumenCil.Text = (pi * r * r * h).ToString("0.##");
        }
        private void btnBorrCil_Click(object sender, EventArgs e)
        { radioCil.Clear(); alturaCil.Clear(); areaCil.Clear(); volumenCil.Clear(); }
        private void btnSalirCil_Click(object sender, EventArgs e) { Close(); }

        // ── Rombo ────────────────────────────────────────────────────────────
        private void btnCalcRombo_Click(object sender, EventArgs e)
        {
            double D = double.Parse(diagD.Text);
            double d = double.Parse(diagd.Text);
            areaRombo.Text = (D * d / 2).ToString("0.##");
        }
        private void btnBorrRombo_Click(object sender, EventArgs e)
        { diagD.Clear(); diagd.Clear(); areaRombo.Clear(); }
        private void btnSalirRombo_Click(object sender, EventArgs e) { Close(); }

        // ── Octaedro ─────────────────────────────────────────────────────────
        private void btnCalcOct_Click(object sender, EventArgs e)
        {
            double a = double.Parse(aristaOct.Text);
            areaOct.Text    = (2 * Math.Sqrt(3) * a * a).ToString("0.##");
            volumenOct.Text = (Math.Sqrt(2) / 3 * Math.Pow(a, 3)).ToString("0.##");
        }
        private void btnBorrOct_Click(object sender, EventArgs e)
        { aristaOct.Clear(); areaOct.Clear(); volumenOct.Clear(); }
        private void btnSalirOct_Click(object sender, EventArgs e) { Close(); }
    }
}
