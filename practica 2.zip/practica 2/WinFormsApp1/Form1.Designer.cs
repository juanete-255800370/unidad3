namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1 - Titulo
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 16F, FontStyle.Bold);
            label1.ForeColor = System.Drawing.Color.Red;
            label1.Location = new Point(90, 30);
            label1.Name = "label1";
            label1.Text = "Hello, Mundo!!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 10F, FontStyle.Bold);
            label2.ForeColor = System.Drawing.Color.DarkRed;
            label2.Location = new Point(40, 110);
            label2.Name = "label2";
            label2.Text = "¿Cuál es tu nombre?";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 10F, FontStyle.Bold);
            label3.ForeColor = System.Drawing.Color.DarkRed;
            label3.Location = new Point(40, 175);
            label3.Name = "label3";
            label3.Text = "Hello, alguien especial!!";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Arial", 10F);
            textBox1.Location = new Point(210, 107);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(180, 31);
            textBox1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.Black;
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.ForeColor = System.Drawing.Color.White;
            button1.Location = new Point(330, 100);
            button1.Name = "button1";
            button1.Size = new Size(130, 36);
            button1.TabIndex = 1;
            button1.Text = "Diga \"Hello\"";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(520, 270);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(button1);
            Name = "Hello_Mundo";
            Text = "Hello";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}
