namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            grpDatos     = new GroupBox();
            lblIngresa   = new Label();
            valor        = new TextBox();
            grpOpciones  = new GroupBox();
            button1      = new Button();
            button2      = new Button();
            button3      = new Button();
            grpResultado = new GroupBox();
            lblEquiv     = new Label();
            label2       = new Label();
            Resultado    = new TextBox();
            grpDatos.SuspendLayout();
            grpOpciones.SuspendLayout();
            grpResultado.SuspendLayout();
            SuspendLayout();
            var bf = new Font("Arial", 10F, FontStyle.Bold);
            // grpDatos
            grpDatos.Controls.Add(lblIngresa); grpDatos.Controls.Add(valor);
            grpDatos.Location = new Point(18, 18); grpDatos.Size = new Size(430, 68); grpDatos.Text = "Datos";
            lblIngresa.AutoSize = true; lblIngresa.Location = new Point(18, 33); lblIngresa.Text = "Ingresa Valor:";
            valor.Location = new Point(128, 30); valor.Name = "valor"; valor.Size = new Size(130, 31); valor.TabIndex = 0;
            // grpOpciones
            grpOpciones.Controls.Add(button1); grpOpciones.Controls.Add(button2); grpOpciones.Controls.Add(button3);
            grpOpciones.Location = new Point(18, 100); grpOpciones.Size = new Size(430, 105); grpOpciones.Text = "Opciones de Conversión";
            button1.Font = bf; button1.Location = new Point(18, 30); button1.Size = new Size(125, 36); button1.Text = "FAHRENHEIT"; button1.Click += button1_Click;
            button2.Font = bf; button2.Location = new Point(158, 30); button2.Size = new Size(140, 36); button2.Text = "CENTÍGRADOS"; button2.Click += button2_Click;
            button3.Font = bf; button3.Location = new Point(148, 68); button3.Size = new Size(110, 32); button3.Text = "BORRAR"; button3.Click += button3_Click;
            // grpResultado
            grpResultado.Controls.Add(lblEquiv); grpResultado.Controls.Add(label2); grpResultado.Controls.Add(Resultado);
            grpResultado.Location = new Point(18, 220); grpResultado.Size = new Size(430, 95); grpResultado.Text = "Resultado en Grados";
            lblEquiv.AutoSize = true; lblEquiv.Location = new Point(18, 38); lblEquiv.Text = "Equivalente en Grados:";
            label2.AutoSize = true; label2.Font = bf; label2.Location = new Point(225, 38); label2.Name = "label2"; label2.Text = "";
            Resultado.Location = new Point(118, 58); Resultado.Name = "Resultado"; Resultado.Size = new Size(155, 31); Resultado.TabIndex = 1; Resultado.ReadOnly = true; Resultado.BackColor = System.Drawing.Color.White;
            // Form1
            ClientSize = new Size(468, 340);
            Controls.Add(grpDatos); Controls.Add(grpOpciones); Controls.Add(grpResultado);
            Name = "Form1"; Text = "Conversiones";
            grpDatos.ResumeLayout(false); grpDatos.PerformLayout();
            grpOpciones.ResumeLayout(false);
            grpResultado.ResumeLayout(false); grpResultado.PerformLayout();
            ResumeLayout(false);
        }

        private System.Windows.Forms.GroupBox grpDatos, grpOpciones, grpResultado;
        private System.Windows.Forms.Label lblIngresa, lblEquiv, label2;
        private System.Windows.Forms.TextBox valor, Resultado;
        private System.Windows.Forms.Button button1, button2, button3;
    }
}
