namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 10F, FontStyle.Bold);
            label1.Location = new Point(40, 50);
            label1.Name = "label1";
            label1.Text = "Primer numero";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 10F, FontStyle.Bold);
            label2.Location = new Point(40, 100);
            label2.Name = "label2";
            label2.Text = "Segundo numero";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 10F, FontStyle.Bold);
            label3.Location = new Point(40, 155);
            label3.Name = "label3";
            label3.Text = "Sum =";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(218, 46);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(130, 31);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(218, 96);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(130, 31);
            textBox2.TabIndex = 1;
            // 
            // button1
            // 
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(112, 200);
            button1.Name = "button1";
            button1.Size = new Size(100, 35);
            button1.TabIndex = 2;
            button1.Text = "SUMAR";
            button1.Click += button1_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(380, 280);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(textBox2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Sumar Numeros";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
    }
}
