namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitulo = new Label();
            lblA1 = new Label();
            lblB1 = new Label();
            lblC1 = new Label();
            lblD1 = new Label();
            lblA2 = new Label();
            lblB2 = new Label();
            lblC2 = new Label();
            lblD2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            var bf = new Font("Arial", 10F, FontStyle.Bold);
            // lblTitulo
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Arial", 11F, FontStyle.Bold);
            lblTitulo.Location = new Point(120, 20);
            lblTitulo.Text = "Escribir numeros en orden inverso";
            // Labels entrada (izquierda)
            string[] nombres = { "Número A", "Número B", "Número C", "Número D" };
            var labsIn  = new[] { lblA1, lblB1, lblC1, lblD1 };
            var labsOut = new[] { lblA2, lblB2, lblC2, lblD2 };
            var tbIn    = new[] { textBox1, textBox2, textBox3, textBox4 };
            var tbOut   = new[] { textBox5, textBox6, textBox7, textBox8 };
            for (int i = 0; i < 4; i++)
            {
                int y = 70 + i * 55;
                labsIn[i].AutoSize  = true;
                labsIn[i].Font      = bf;
                labsIn[i].Location  = new Point(30, y + 4);
                labsIn[i].Text      = nombres[i];
                tbIn[i].Location    = new Point(140, y);
                tbIn[i].Size        = new Size(110, 31);
                tbIn[i].TabIndex    = i;
                labsOut[i].AutoSize = true;
                labsOut[i].Font     = bf;
                labsOut[i].Location = new Point(295, y + 4);
                labsOut[i].Text     = nombres[i];
                tbOut[i].Location   = new Point(410, y);
                tbOut[i].Size       = new Size(110, 31);
                tbOut[i].TabIndex   = 8 + i;
                tbOut[i].ReadOnly   = true;
                tbOut[i].BackColor  = System.Drawing.Color.White;
            }
            // button1
            button1.Font = new Font("Arial", 10F, FontStyle.Bold);
            button1.Location = new Point(200, 310);
            button1.Name = "button1";
            button1.Size = new Size(140, 36);
            button1.TabIndex = 16;
            button1.Text = "Invertir Orden";
            button1.Click += button1_Click;
            // Form1
            ClientSize = new Size(565, 380);
            Controls.Add(lblTitulo);
            foreach (var c in labsIn)  Controls.Add(c);
            foreach (var c in labsOut) Controls.Add(c);
            foreach (var c in tbIn)    Controls.Add(c);
            foreach (var c in tbOut)   Controls.Add(c);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Invertir Números";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo, lblA1, lblB1, lblC1, lblD1;
        private System.Windows.Forms.Label lblA2, lblB2, lblC2, lblD2;
        private System.Windows.Forms.TextBox textBox1, textBox2, textBox3, textBox4;
        private System.Windows.Forms.TextBox textBox5, textBox6, textBox7, textBox8;
        private System.Windows.Forms.Button button1;
    }
}
