namespace WinFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblTitulo = new Label();
            lblBase   = new Label();
            lblAltura = new Label();
            lblArea   = new Label();
            textBox1  = new TextBox();
            textBox2  = new TextBox();
            textBox3  = new TextBox();
            button1   = new Button();
            SuspendLayout();
            var bf = new Font("Arial", 11F, FontStyle.Bold);
            // lblTitulo
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Arial", 14F, FontStyle.Bold);
            lblTitulo.Location = new Point(95, 22);
            lblTitulo.Text = "Area Triángulo";
            // lblBase
            lblBase.AutoSize = true; lblBase.Font = bf;
            lblBase.Location = new Point(45, 95); lblBase.Text = "Base";
            // textBox1
            textBox1.Location = new Point(170, 91); textBox1.Name = "textBox1";
            textBox1.Size = new Size(130, 31); textBox1.TabIndex = 0;
            // lblAltura
            lblAltura.AutoSize = true; lblAltura.Font = bf;
            lblAltura.Location = new Point(45, 150); lblAltura.Text = "Altura";
            // textBox2
            textBox2.Location = new Point(170, 146); textBox2.Name = "textBox2";
            textBox2.Size = new Size(130, 31); textBox2.TabIndex = 1;
            // lblArea
            lblArea.AutoSize = true; lblArea.Font = bf;
            lblArea.Location = new Point(45, 215); lblArea.Text = "Area";
            // textBox3
            textBox3.Location = new Point(170, 211); textBox3.Name = "textBox3";
            textBox3.Size = new Size(130, 31); textBox3.TabIndex = 2;
            textBox3.ReadOnly = true; textBox3.BackColor = System.Drawing.Color.White;
            // button1
            button1.Font = bf; button1.Location = new Point(130, 280);
            button1.Size = new Size(90, 32); button1.TabIndex = 3; button1.Text = "button1";
            button1.Click += button1_Click;
            // Form1
            ClientSize = new Size(390, 355);
            Controls.Add(lblTitulo); Controls.Add(lblBase); Controls.Add(lblAltura); Controls.Add(lblArea);
            Controls.Add(textBox1); Controls.Add(textBox2); Controls.Add(textBox3);
            Controls.Add(button1);
            Name = "Form1"; Text = "Área Triángulo";
            ResumeLayout(false); PerformLayout();
        }

        private System.Windows.Forms.Label lblTitulo, lblBase, lblAltura, lblArea;
        private System.Windows.Forms.TextBox textBox1, textBox2, textBox3;
        private System.Windows.Forms.Button button1;
    }
}
